function getColorForType(type) {
    const typeMapping = {
        'grass': { name: 'Planta', color: "#78C850" },
        'poison': { name: 'Veneno', color: "#A040A0" },
        'fire': { name: 'Fogo', color: "#F08030" },
        'water': { name: 'Água', color: "#6890F0" },
        'bug': { name: 'Inseto', color: "#A8B820" },
        'flying': { name: 'Voador', color: "#A890F0" },
        'normal': { name: 'Normal', color: "#A8A878" },
        'electric': { name: 'Elétrico', color: "#F8D030" },
        'psychic': { name: 'Psíquico', color: "#F85888" },
        'ice': { name: 'Gelo', color: "#98D8D8" },
        'dragon': { name: 'Dragão', color: "#7038F8" },
        'fighting': { name: 'Lutador', color: "#C03028" },
        'rock': { name: 'Pedra', color: "#B8A038" },
        'ground': { name: 'Terrestre', color: "#E0C068" },
        'ghost': { name: 'Fantasma', color: "#705898" },
        'steel': { name: 'Aço', color: "#B8B8D0" },
        'fairy': { name: 'Fada', color: "#EE99AC" },
        'dark': { name: 'Sombrio', color: "#705848" },
    };

    const lowerCaseType = type.toLowerCase();

    return typeMapping[lowerCaseType]?.color || "#888";
}

function ContentPokedex({ pokemons, loading, error, searchTerm }) { 
    return (
        <div className="pokedex-content w-full  flex flex-col items-center p-8">

            {loading && <p className="text-xl text-gray-700">Carregando Pokémon...</p>}
            {error && <p className="text-xl text-red-600">Erro: {error}</p>}
            {!loading && !error && pokemons.length === 0 && searchTerm.trim() !== '' && (
                <p className="text-xl text-gray-700">Nenhum Pokémon encontrado com o termo de busca: "{searchTerm}"</p>
            )}

            {!loading && !error && pokemons.length > 0 && (
                <div className="pokemon-grid w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {pokemons.map((p) => (
                        <div key={p.id} className="pokemon-card bg-white flex flex-col items-center h-[240px] p-4 rounded-lg shadow-md transition-transform duration-200 hover:scale-105">
                            <img src={p.img} alt={p.name} className="pokemon-img w-28 h-28 object-contain mb-2" />
                            <span className="pokemon-id text-xs text-gray-500">Nº {p.id}</span>
                            <strong className="pokemon-name text-lg font-bold mb-2">{p.name}</strong>
                            <div className="pokemon-types flex gap-1 flex-wrap justify-center">
                                {p.types.map((t) => (
                                    <span
                                        key={t}
                                        className="pokemon-type text-white text-xs px-2 py-1 rounded-full font-medium"
                                        style={{ backgroundColor: getColorForType(t) }}
                                    >
                                        {t}
                                    </span>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default ContentPokedex;