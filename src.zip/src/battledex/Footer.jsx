function Footer() {

    return (
        <footer className="footer w-full bg-[var(--color-red)] flex flex-col sm:flex-row justify-center sm:justify-between items-center px-4 py-2 text-white text-start sm:text-left">
            <p>&copy; 2025 BattleDex. Todos os direitos reservados. </p>
            <p>Desenvolvido por Gabriel Marcelo e João Pedro </p>
        </footer>
    )
}

export default Footer;