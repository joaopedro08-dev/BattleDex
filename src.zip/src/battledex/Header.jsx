import { useState } from 'react';
import logo from '../assets/imgs/logo.png';
import HeaderResponsive from '../components/HeaderResponsive';
import HeaderLanguage from '../components/HeaderLanguage';

function Header() {
    const [menuOpen, setMenuOpen] = useState(false);

    const navbar = ["Pokedéx", "Treinamentos", "Canais", "Sobre"];

    const toggleMenu = () => setMenuOpen(prev => !prev);
    const closeMenu = () => setMenuOpen(false);

    return (
        <header className='header w-full bg-[var(--color-red)] px-4 py-2 flex justify-between items-center'>
            <div className="flex items-center gap-2">
                <button
                    className='md:hidden text-white text-3xl bg-transparent border-none'
                    onClick={toggleMenu}
                    aria-label="Abrir menu"
                    aria-expanded={menuOpen}
                >
                    <i className="fa-solid fa-bars"></i>
                </button>
                <a href="/">
                    <img className='w-36 md:w-44' src={logo} alt="Logo" />
                </a>
            </div>

            <nav className="hidden md:flex flex-1 justify-center">
                <ul className='flex gap-8 list-none m-0 p-0'>
                    {navbar.map((item, index) => (
                        <li key={index} className='relative text-[var(--color-white)] font-medium text-base uppercase tracking-wider cursor-pointer
              transition-all duration-300 hover:[text-shadow:0_0_5px_var(--color-black)]
              after:absolute after:left-0 after:bottom-0 after:h-[2px] after:w-0 after:bg-[var(--color-black)]
              hover:after:w-full after:transition-all after:duration-300'>
                            {item}
                        </li>
                    ))}
                </ul>
            </nav>

            <HeaderLanguage />

            <HeaderResponsive
                menuOpen={menuOpen}
                closeMenu={closeMenu}
                navbar={navbar}
            />
        </header>
    );
}

export default Header;