function Training(){}

export default Training;